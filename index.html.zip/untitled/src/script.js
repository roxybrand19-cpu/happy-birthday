document.getElementsByTagName("h1")[0].style.fontSize = "6vw";
